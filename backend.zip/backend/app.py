# ========================================================================================
# NOVASCORE FINANCIAL ASSESSMENT PLATFORM - FLASK BACKEND WITH MONGODB
# ========================================================================================
# Flask backend for partner creditworthiness assessment system
# ========================================================================================

from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from werkzeug.exceptions import BadRequest
import pandas as pd
import numpy as np
import json
import io
from datetime import datetime, timedelta
import uuid
import logging
from typing import Optional, List, Dict, Any
from typing import Dict, Any, List
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.schema import HumanMessage
import json
import os
import pickle
import joblib
from catboost import CatBoostRegressor
import warnings
warnings.filterwarnings('ignore')

# MongoDB imports
from pymongo import MongoClient, ASCENDING, DESCENDING
from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError
from bson.objectid import ObjectId
from bson.errors import InvalidId

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Add CORS support - restrict in production
CORS(app, origins=["http://localhost:3000", "http://localhost:3001","http://localhost:5173"])  # Add your frontend URLs

# ========================================================================================
# MONGODB CONFIGURATION
# ========================================================================================

class MongoDBManager:
    def __init__(self, connection_string: str = None, database_name: str = "novascore_db"):
        """Initialize MongoDB connection"""
        self.connection_string = connection_string or os.getenv('MONGODB_URI', 'mongodb+srv://soni3anuj:Anuj@cluster0.5liuseb.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
        self.database_name = database_name
        self.client = None
        self.db = None
        self.connect()
    
    def connect(self):
        """Establish MongoDB connection"""
        try:
            self.client = MongoClient(
                self.connection_string,
                serverSelectionTimeoutMS=5000,  # 5 second timeout
                connectTimeoutMS=10000,  # 10 second connection timeout
                socketTimeoutMS=20000,   # 20 second socket timeout
            )
            
            # Test the connection
            self.client.admin.command('ismaster')
            self.db = self.client[self.database_name]
            
            # Create indexes for better performance
            self.create_indexes()
            
            logger.info(f"Connected to MongoDB: {self.database_name}")
            
        except (ConnectionFailure, ServerSelectionTimeoutError) as e:
            logger.error(f"MongoDB connection failed: {e}")
            raise ConnectionError("Failed to connect to MongoDB. Please check your connection string and ensure MongoDB is running.")
    
    def create_indexes(self):
        """Create database indexes for better performance"""
        try:
            # Assessments collection indexes
            assessments = self.db.assessments
            assessments.create_index([("created_at", DESCENDING)])
            assessments.create_index([("partner_type", ASCENDING)])
            assessments.create_index([("nova_score", DESCENDING)])
            assessments.create_index([("risk_category", ASCENDING)])
            assessments.create_index([("loan_approved", ASCENDING)])
            
            logger.info("Database indexes created successfully")
            
        except Exception as e:
            logger.error(f"Index creation failed: {e}")
    
    def close_connection(self):
        """Close MongoDB connection"""
        if self.client:
            self.client.close()
            logger.info("MongoDB connection closed")

# Initialize MongoDB manager
try:
    mongo_manager = MongoDBManager()
except ConnectionError as e:
    logger.error(f"MongoDB initialization failed: {e}")
    mongo_manager = None

class MLModelPredictor:
    def __init__(self):
        self.model = None
        self.feature_scaler = None
        self.partner_type_encoder = None
        self.feature_names = []
        self.load_model_artifacts()
    
    def load_model_artifacts(self):
        """Load trained model and preprocessing artifacts"""
        try:
            # Load the trained CatBoost model
            self.model = CatBoostRegressor()
            self.model.load_model('best_nova_score_model.pkl')
            print("✓ Model loaded successfully")
            
            # Load feature scaler
            with open('feature_scaler.pkl', 'rb') as f:
                self.feature_scaler = pickle.load(f)
            print("✓ Feature scaler loaded successfully")
            
            # Load partner type encoder
            with open('partner_type_encoder.pkl', 'rb') as f:
                self.partner_type_encoder = pickle.load(f)
            print("✓ Partner type encoder loaded successfully")
            
            # Load feature names from model_info.json
            with open('model_info.json', 'r') as f:
                model_info = json.load(f)
                self.feature_names = model_info['feature_names']
            print(f"✓ Loaded {len(self.feature_names)} feature names")
            
        except Exception as e:
            print(f"❌ Error loading model artifacts: {e}")
            print("Falling back to rule-based scoring")
    
    def create_engineered_features(self, partner_type: str, data: Dict[str, Any]) -> Dict[str, float]:
        """Create engineered features from raw data"""
        features = {}
        
        # Basic features
        monthly_earning = data.get('monthly_earning', 0)
        yearly_earning = data.get('yearly_earning', 0)
        active_days = max(data.get('active_days', 1), 1)  # Avoid division by zero
        working_tenure_ingrab = max(data.get('working_tenure_ingrab', 1), 1)
        
        # Raw features
        features['earning_consistency'] = data.get('earning_consistency', 0.8)
        features['monthly_earning'] = monthly_earning
        features['yearly_earning'] = yearly_earning
        features['customer_rating'] = data.get('customer_rating', 4.0)
        features['active_days'] = active_days
        features['cancellation_rate'] = data.get('cancellation_rate', 0.05)
        features['complaint_rate'] = data.get('complaint_rate', 0.03)
        features['working_tenure_ingrab'] = working_tenure_ingrab
        
        # Partner type specific features
        if partner_type == 'driver':
            features['total_trips'] = data.get('total_trips', 0)
            features['vehicle_age'] = data.get('vehicle_age', 2)
            features['trip_distance'] = data.get('trip_distance', 10)
            features['peak_hours_ratio'] = data.get('peak_hours_ratio', 0.3)
            features['total_orders'] = 0
            features['avg_ordervalue'] = 0
            features['preparation_time'] = 0
            features['menu_diversity'] = 0
            features['consumer_retention_rate'] = 0
            features['total_deliveries'] = 0
            features['avg_delivery_time'] = 0
            features['delivery_success_rate'] = 0
            features['batch_delivery_ratio'] = 0
        
        elif partner_type == 'merchant':
            features['total_orders'] = data.get('total_orders', 0)
            features['avg_ordervalue'] = data.get('avg_ordervalue', 200)
            features['preparation_time'] = data.get('preparation_time', 15)
            features['menu_diversity'] = data.get('menu_diversity', 10)
            features['consumer_retention_rate'] = data.get('consumer_retention_rate', 0.7)
            features['total_trips'] = 0
            features['vehicle_age'] = 0
            features['trip_distance'] = 0
            features['peak_hours_ratio'] = 0
            features['total_deliveries'] = 0
            features['avg_delivery_time'] = 0
            features['delivery_success_rate'] = 0
            features['batch_delivery_ratio'] = 0
        
        elif partner_type == 'delivery_partner':
            features['total_deliveries'] = data.get('total_deliveries', 0)
            features['avg_delivery_time'] = data.get('avg_delivery_time', 25)
            features['delivery_success_rate'] = data.get('delivery_success_rate', 0.95)
            features['batch_delivery_ratio'] = data.get('batch_delivery_ratio', 0.4)
            features['total_trips'] = 0
            features['vehicle_age'] = 0
            features['trip_distance'] = 0
            features['peak_hours_ratio'] = 0
            features['total_orders'] = 0
            features['avg_ordervalue'] = 0
            features['preparation_time'] = 0
            features['menu_diversity'] = 0
            features['consumer_retention_rate'] = 0
        
        # Encode partner type
        try:
            features['partner_type_encoded'] = self.partner_type_encoder.transform([partner_type])[0]
        except:
            # Fallback encoding
            type_mapping = {'driver': 0, 'merchant': 1, 'delivery_partner': 2}
            features['partner_type_encoded'] = type_mapping.get(partner_type, 0)
        
        # Engineered features
        features['earnings_per_active_day'] = monthly_earning / active_days
        features['earning_consistency_ratio'] = yearly_earning / max(monthly_earning * 12, 1)
        features['activity_per_tenure'] = active_days / working_tenure_ingrab
        features['total_negative_rate'] = features['cancellation_rate'] + features['complaint_rate']
        features['rating_to_complaint_ratio'] = features['customer_rating'] / max(features['complaint_rate'], 0.001)
        
        # Partner-specific engineered features
        if partner_type == 'driver' and features['total_trips'] > 0:
            features['trips_per_active_day'] = features['total_trips'] / active_days
            features['earning_per_trip'] = monthly_earning / features['total_trips']
        else:
            features['trips_per_active_day'] = 0
            features['earning_per_trip'] = 0
        
        if partner_type == 'merchant' and features['total_orders'] > 0:
            features['orders_per_active_day'] = features['total_orders'] / active_days
            features['earning_per_order'] = monthly_earning / features['total_orders']
        else:
            features['orders_per_active_day'] = 0
            features['earning_per_order'] = 0
        
        if partner_type == 'delivery_partner' and features['total_deliveries'] > 0:
            features['deliveries_per_active_day'] = features['total_deliveries'] / active_days
            features['earning_per_delivery'] = monthly_earning / features['total_deliveries']
        else:
            features['deliveries_per_active_day'] = 0
            features['earning_per_delivery'] = 0
        
        return features
    
    def predict_nova_score(self, partner_type: str, data: Dict[str, Any]) -> float:
        """Predict Nova Score using trained ML model"""
        if not self.model:
            # Fallback to rule-based calculation
            return self.rule_based_score(partner_type, data)
        
        try:
            # Create engineered features
            features = self.create_engineered_features(partner_type, data)
            
            # Ensure all required features are present
            feature_vector = []
            for feature_name in self.feature_names:
                feature_vector.append(features.get(feature_name, 0))
            
            # Convert to numpy array and reshape
            feature_array = np.array(feature_vector).reshape(1, -1)
            
            # Scale features
            if self.feature_scaler:
                feature_array = self.feature_scaler.transform(feature_array)
            
            # Predict using the model
            prediction = self.model.predict(feature_array)[0]
            
            # Ensure prediction is within valid range
            nova_score = max(0, min(100, float(prediction)))
            
            return round(nova_score, 2)
            
        except Exception as e:
            print(f"ML prediction error: {e}, falling back to rule-based")
            return self.rule_based_score(partner_type, data)
    
    def rule_based_score(self, partner_type: str, data: Dict[str, Any]) -> float:
        """Fallback rule-based scoring"""
        score = 0.0
        
        # Extract common features
        monthly_earning = data.get('monthly_earning', 0)
        customer_rating = data.get('customer_rating', 0)
        active_days = data.get('active_days', 0)
        working_tenure_ingrab = data.get('working_tenure_ingrab', 0)
        complaint_rate = data.get('complaint_rate', 0.03)
        cancellation_rate = data.get('cancellation_rate', 0.05)
        
        # 1. Earnings Score (35% weight)
        earnings_score = min(35, (monthly_earning / 5000) * 35)
        score += earnings_score
        
        # 2. Customer Rating Score (25% weight)
        rating_score = ((customer_rating - 1) / 4) * 25
        score += rating_score
        
        # 3. Activity Score (20% weight)
        activity_score = (active_days / 30) * 20
        score += activity_score
        
        # 4. Experience Score (10% weight)
        experience_score = min(10, (working_tenure_ingrab / 24) * 10)
        score += experience_score
        
        # 5. Partner-specific bonus (5% weight)
        if partner_type == 'driver':
            peak_bonus = data.get('peak_hours_ratio', 0) * 3
            trip_efficiency = min(2, data.get('total_trips', 0) / max(working_tenure_ingrab, 1) / 50)
            score += peak_bonus + trip_efficiency
        elif partner_type == 'merchant':
            retention_bonus = data.get('consumer_retention_rate', 0) * 3
            order_efficiency = min(2, data.get('avg_ordervalue', 0) / 300)
            score += retention_bonus + order_efficiency
        elif partner_type == 'delivery_partner':
            success_bonus = data.get('delivery_success_rate', 0) * 3
            speed_bonus = max(0, 2 - (data.get('avg_delivery_time', 30) / 30))
            score += success_bonus + speed_bonus
        
        # 6. Quality penalties (5% weight)
        quality_penalty = (complaint_rate + cancellation_rate) * 50
        score -= quality_penalty
        
        # Ensure score is between 0-100
        return max(0, min(100, round(score, 2)))

# Initialize the ML predictor globally
ml_predictor = MLModelPredictor()

# ========================================================================================
# NOVA SCORE CALCULATOR CLASS
# ========================================================================================

class NovaScoreCalculator:
    
    @staticmethod
    def calculate_score(partner_type: str, data: Dict[str, Any]) -> float:
        """Calculate Nova Score using trained ML model"""
        return ml_predictor.predict_nova_score(partner_type, data)
    
    @staticmethod
    def get_risk_category(nova_score: float) -> str:
        """Get risk category based on Nova Score"""
        if nova_score >= 80:
            return "Excellent"
        elif nova_score >= 65:
            return "Good"
        elif nova_score >= 50:
            return "Fair"
        else:
            return "Poor"
    
    @staticmethod
    def make_loan_decision(nova_score: float, monthly_earning: int, tenure_months: int) -> Dict[str, Any]:
        """Make loan decision based on Nova Score and business rules"""
        
        # Business rules
        min_score = 45
        min_earning = 1000
        min_tenure = 3
        
        # Check eligibility
        eligible = (nova_score >= min_score and 
                   monthly_earning >= min_earning and 
                   tenure_months >= min_tenure)
        
        if not eligible:
            return {
                'approved': False,
                'reason': f'Does not meet minimum criteria (Score: {min_score}+, Earning: ₹{min_earning}+, Tenure: {min_tenure}+ months)',
                'max_amount': 0,
                'interest_rate': 0,
                'tenure_months': 0
            }
        
        # Calculate loan terms based on Nova Score
        if nova_score >= 80:
            max_amount = monthly_earning * 40
            interest_rate = 10.5
            tenure_months_offered = 36
        elif nova_score >= 65:
            max_amount = monthly_earning * 30
            interest_rate = 12.5
            tenure_months_offered = 24
        elif nova_score >= 50:
            max_amount = monthly_earning * 20
            interest_rate = 15.0
            tenure_months_offered = 18
        else:
            max_amount = monthly_earning * 15
            interest_rate = 18.0
            tenure_months_offered = 12
        
        # Cap maximum loan amount
        max_amount = min(max_amount, 500000)
        
        return {
            'approved': True,
            'max_amount': int(max_amount),
            'interest_rate': interest_rate,
            'tenure_months': tenure_months_offered,
            'monthly_emi': int((max_amount * (interest_rate/100/12) * (1 + interest_rate/100/12)**tenure_months_offered) / 
                              ((1 + interest_rate/100/12)**tenure_months_offered - 1))
        }

    @staticmethod
    def get_recommendations(nova_score: float, data: Dict[str, Any], google_api_key: str = None) -> List[str]:
        """Generate improvement recommendations using Google Gemini 1.5 Flash"""
        
        try:
            # Use environment variable or fallback (remove hardcoded key in production)
            api_key = google_api_key or os.getenv('GOOGLE_API_KEY')
            
            if not api_key:
                raise ValueError("Google API key not provided")
            
            # Initialize Gemini 1.5 Flash model
            llm = ChatGoogleGenerativeAI(
                model="gemini-1.5-flash",
                google_api_key=api_key,
                temperature=0.3,
                max_tokens=1000
            )
            
            # Prepare the prompt with user data
            prompt = f"""
            You are an expert performance analyst for gig economy workers. Based on the following performance data, 
            generate exactly 5 personalized improvement recommendations.
            
            Performance Data:
            - NOVA Score: {nova_score}/100
            - Monthly Earning: ${data.get('monthly_earning', 0)}
            - Customer Rating: {data.get('customer_rating', 5.0)}/5.0
            - Active Days: {data.get('active_days', 30)} days
            - Complaint Rate: {data.get('complaint_rate', 0):.2%}
            - Cancellation Rate: {data.get('cancellation_rate', 0):.2%}
            - Total Trips/Orders: {data.get('total_trips', 0)}
            - On-time Delivery Rate: {data.get('ontime_rate', 1.0):.1%}
            
            Guidelines:
            1. Be specific and actionable
            2. Use appropriate emojis
            3. Prioritize most impactful improvements
            4. Consider NOVA score level (80+: premium focus, 65-79: incremental, 50-64: major gaps, <50: fundamentals)
            5. One concise sentence per recommendation
            
            Return exactly 5 recommendations in JSON format:
            {{"recommendations": ["rec1", "rec2", "rec3", "rec4", "rec5"]}}
            """
            
            # Generate recommendations using Gemini
            message = HumanMessage(content=prompt)
            response = llm([message])
            
            # Parse JSON response
            response_data = json.loads(response.content.strip())
            recommendations = response_data.get('recommendations', [])
            
            # Ensure exactly 5 recommendations
            if len(recommendations) >= 5:
                return recommendations[:5]
            
        except Exception as e:
            print(f"AI recommendation error: {e}, falling back to rule-based")
        
        # Fallback to rule-based recommendations
        recommendations = []
        
        if data.get('monthly_earning', 0) < 3000:
            recommendations.append("💰 Consider increasing active working hours to boost monthly earnings")
        
        if data.get('customer_rating', 5.0) < 4.0:
            recommendations.append("⭐ Focus on improving customer service to increase ratings")
        
        if data.get('active_days', 30) < 20:
            recommendations.append("📈 Increase active working days for better consistency")
        
        if data.get('working_tenure_ingrab', 0) < 12:
            recommendations.append("🕒 Build more experience with Grab to unlock better opportunities")
        
        if not data.get('loan_approved', True):
            recommendations.append("💳 Improve financial metrics to increase loan approval chances")
        
        if data.get('yearly_earning', 0) < data.get('monthly_earning', 0) * 10:
            recommendations.append("📊 Focus on maintaining consistent monthly earnings throughout the year")
        
        if nova_score >= 80:
            recommendations.append("🏆 Excellent performance! Consider applying for premium services")
        elif nova_score >= 65:
            recommendations.append("✅ Good performance! Small improvements can unlock better rates")
        elif nova_score >= 50:
            recommendations.append("📈 Focus on key metrics to reach the next performance tier")
        else:
            recommendations.append("🎯 Prioritize fundamental improvements in service quality and consistency")
        
        return recommendations[:5]

# ========================================================================================
# MONGODB DATABASE OPERATIONS
# ========================================================================================

def save_assessment(assessment_data: Dict[str, Any]) -> str:
    """Save assessment to MongoDB"""
    if mongo_manager is None or mongo_manager.db is None:
        raise RuntimeError("MongoDB connection not available")
    
    try:
        # Add MongoDB-specific fields
        assessment_data['_id'] = str(uuid.uuid4())
        assessment_data['created_at'] = datetime.utcnow()
        assessment_data['updated_at'] = datetime.utcnow()
        
        # Insert document
        result = mongo_manager.db.assessments.insert_one(assessment_data)
        
        return assessment_data['_id']
        
    except Exception as e:
        logger.error(f"Failed to save assessment: {e}")
        raise RuntimeError(f"Database save failed: {e}")

def get_assessment_history(limit: int = 100, partner_type: str = None) -> List[Dict[str, Any]]:
    """Get assessment history from MongoDB"""
    if mongo_manager is None or mongo_manager.db is None:
        raise RuntimeError("MongoDB connection not available")
    
    try:
        # Build query filter
        query = {}
        if partner_type:
            query['partner_type'] = partner_type
        
        # Execute query with sorting and limit
        cursor = mongo_manager.db.assessments.find(
            query,
            {'_id': 1, 'partner_type': 1, 'partner_name': 1, 'nova_score': 1, 
             'risk_category': 1, 'loan_approved': 1, 'loan_amount': 1, 
             'interest_rate': 1, 'created_at': 1}
        ).sort('created_at', DESCENDING).limit(limit)
        
        # Convert cursor to list and handle ObjectId serialization
        results = []
        for doc in cursor:
            doc['id'] = doc.pop('_id')  # Rename _id to id for frontend
            if isinstance(doc.get('created_at'), datetime):
                doc['created_at'] = doc['created_at'].isoformat()
            results.append(doc)
        
        return results
        
    except Exception as e:
        logger.error(f"Failed to retrieve assessment history: {e}")
        raise RuntimeError(f"Database query failed: {e}")

def get_assessment_by_id(assessment_id: str) -> Optional[Dict[str, Any]]:
    """Get specific assessment by ID"""
    if mongo_manager is None or mongo_manager.db is None:
        raise RuntimeError("MongoDB connection not available")
    
    try:
        # Find document by ID
        doc = mongo_manager.db.assessments.find_one({'_id': assessment_id})
        
        if doc:
            doc['id'] = doc.pop('_id')  # Rename _id to id
            if isinstance(doc.get('created_at'), datetime):
                doc['created_at'] = doc['created_at'].isoformat()
            if isinstance(doc.get('updated_at'), datetime):
                doc['updated_at'] = doc['updated_at'].isoformat()
        
        return doc
        
    except Exception as e:
        logger.error(f"Failed to retrieve assessment {assessment_id}: {e}")
        return None

def get_dashboard_stats() -> Dict[str, Any]:
    """Get dashboard statistics from MongoDB"""
    if mongo_manager is None or mongo_manager.db is None:
        raise RuntimeError("MongoDB connection not available")
    
    try:
        collection = mongo_manager.db.assessments
        
        # Total assessments
        total_assessments = collection.count_documents({})
        
        # Approval rate
        approved_count = collection.count_documents({'loan_approved': True})
        approval_rate = (approved_count / max(total_assessments, 1)) * 100
        
        # Average Nova Score
        pipeline = [
            {'$group': {'_id': None, 'avg_score': {'$avg': '$nova_score'}}}
        ]
        avg_result = list(collection.aggregate(pipeline))
        avg_nova_score = avg_result[0]['avg_score'] if avg_result else 0
        
        # Risk distribution
        risk_pipeline = [
            {'$group': {'_id': '$risk_category', 'count': {'$sum': 1}}}
        ]
        risk_results = list(collection.aggregate(risk_pipeline))
        risk_distribution = {item['_id']: item['count'] for item in risk_results}
        
        # Partner type distribution
        partner_pipeline = [
            {'$group': {'_id': '$partner_type', 'count': {'$sum': 1}}}
        ]
        partner_results = list(collection.aggregate(partner_pipeline))
        partner_distribution = {item['_id']: item['count'] for item in partner_results}
        
        # Recent assessments trend (last 7 days)
        seven_days_ago = datetime.utcnow() - timedelta(days=7)
        daily_pipeline = [
            {'$match': {'created_at': {'$gte': seven_days_ago}}},
            {'$group': {
                '_id': {
                    '$dateToString': {
                        'format': '%Y-%m-%d',
                        'date': '$created_at'
                    }
                },
                'count': {'$sum': 1}
            }},
            {'$sort': {'_id': 1}}
        ]
        daily_results = list(collection.aggregate(daily_pipeline))
        daily_assessments = [{'date': item['_id'], 'count': item['count']} for item in daily_results]
        
        return {
            'total_assessments': total_assessments,
            'approval_rate': round(approval_rate, 2),
            'avg_nova_score': round(avg_nova_score, 2),
            'risk_distribution': risk_distribution,
            'partner_distribution': partner_distribution,
            'daily_assessments': daily_assessments
        }
        
    except Exception as e:
        logger.error(f"Failed to generate dashboard stats: {e}")
        raise RuntimeError(f"Dashboard stats generation failed: {e}")

# ========================================================================================
# VALIDATION FUNCTIONS
# ========================================================================================

def validate_partner_data(partner_type: str, data: Dict[str, Any]) -> Dict[str, Any]:
    """Validate partner data based on type"""
    errors = []
    
    # Common validations
    if 'customer_rating' in data:
        if not isinstance(data['customer_rating'], (int, float)) or not (1.0 <= data['customer_rating'] <= 5.0):
            errors.append('Customer rating must be between 1.0 and 5.0')
    
    if 'active_days' in data:
        if not isinstance(data['active_days'], int) or not (0 <= data['active_days'] <= 31):
            errors.append('Active days must be between 0 and 31')
    
    # Partner-specific validations
    if partner_type == 'driver':
        if 'peak_hours_ratio' in data:
            if not isinstance(data['peak_hours_ratio'], (int, float)) or not (0.0 <= data['peak_hours_ratio'] <= 1.0):
                errors.append('Peak hours ratio must be between 0.0 and 1.0')
                
    elif partner_type == 'merchant':
        if 'consumer_retention_rate' in data:
            if not isinstance(data['consumer_retention_rate'], (int, float)) or not (0.0 <= data['consumer_retention_rate'] <= 1.0):
                errors.append('Consumer retention rate must be between 0.0 and 1.0')
                
    elif partner_type == 'delivery_partner':
        if 'delivery_success_rate' in data:
            if not isinstance(data['delivery_success_rate'], (int, float)) or not (0.0 <= data['delivery_success_rate'] <= 1.0):
                errors.append('Delivery success rate must be between 0.0 and 1.0')
        if 'batch_delivery_ratio' in data:
            if not isinstance(data['batch_delivery_ratio'], (int, float)) or not (0.0 <= data['batch_delivery_ratio'] <= 1.0):
                errors.append('Batch delivery ratio must be between 0.0 and 1.0')
    
    if errors:
        raise ValueError('; '.join(errors))
    
    return data

def validate_partner_type(partner_type: str) -> bool:
    """Validate partner type"""
    return partner_type in ['driver', 'merchant', 'delivery_partner']

# ========================================================================================
# ERROR HANDLERS
# ========================================================================================

@app.errorhandler(400)
def bad_request(error):
    return jsonify({'error': 'Bad request', 'message': str(error)}), 400

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not found', 'message': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error', 'message': 'An unexpected error occurred'}), 500

# ========================================================================================
# API ROUTES
# ========================================================================================

@app.route("/", methods=['GET'])
def root():
    """Root endpoint"""
    return jsonify({
        "message": "NovaScore Financial Assessment Platform API",
        "version": "2.0.0",
        "status": "active",
        "database": "MongoDB" if mongo_manager else "Not connected"
    })

@app.route("/api/partner-types", methods=['GET'])
def get_partner_types():
    """Get available partner types"""
    return jsonify({
        "partner_types": [
            {
                "id": "driver",
                "name": "Driver",
                "description": "Vehicle drivers for ride-sharing services",
                "required_fields": ["total_trips", "vehicle_age", "trip_distance", "peak_hours_ratio"]
            },
            {
                "id": "merchant",
                "name": "Merchant",
                "description": "Restaurant and store partners",
                "required_fields": ["total_orders", "avg_ordervalue", "preparation_time", "menu_diversity", "consumer_retention_rate"]
            },
            {
                "id": "delivery_partner",
                "name": "Delivery Partner",
                "description": "Food and package delivery partners",
                "required_fields": ["total_deliveries", "avg_delivery_time", "delivery_success_rate", "batch_delivery_ratio"]
            }
        ]
    })

@app.route("/api/model-info", methods=['GET'])
def get_model_info():
    """Get model information and status"""
    return jsonify({
        "model_loaded": ml_predictor.model is not None,
        "feature_count": len(ml_predictor.feature_names),
        "feature_names": ml_predictor.feature_names[:10],  # First 10 features
        "model_type": "CatBoost" if ml_predictor.model else "Rule-based fallback",
        "scaler_loaded": ml_predictor.feature_scaler is not None,
        "encoder_loaded": ml_predictor.partner_type_encoder is not None,
        "database_status": "MongoDB Connected" if mongo_manager else "MongoDB Disconnected"
    })

@app.route("/api/assess-partner", methods=['POST'])
def assess_partner():
    """Assess a single partner"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        partner_type = data.get('partner_type')
        partner_data = data.get('partner_data', {})
        
        if not partner_type:
            return jsonify({'error': 'Partner type is required'}), 400
        
        if not validate_partner_type(partner_type):
            return jsonify({'error': 'Invalid partner type. Must be driver, merchant, or delivery_partner'}), 400
        
        # Validate partner data
        validate_partner_data(partner_type, partner_data)
        
        # Calculate Nova Score
        calculator = NovaScoreCalculator()
        nova_score = calculator.calculate_score(partner_type, partner_data)
        
        # Get risk category
        risk_category = calculator.get_risk_category(nova_score)
        
        # Make loan decision
        loan_decision = calculator.make_loan_decision(
            nova_score, 
            partner_data.get('monthly_earning', 0),
            partner_data.get('working_tenure_ingrab', 0)
        )
        
        # Get recommendations
        recommendations = calculator.get_recommendations(nova_score, partner_data)
        
        # Save to MongoDB
        assessment_data = {
            'partner_type': partner_type,
            'partner_name': partner_data.get('partner_name', 'Partner'),
            'monthly_earning': partner_data.get('monthly_earning', 0),
            'yearly_earning': partner_data.get('yearly_earning', 0),
            'customer_rating': partner_data.get('customer_rating', 0),
            'active_days': partner_data.get('active_days', 0),
            'working_tenure_ingrab': partner_data.get('working_tenure_ingrab', 0),
            'nova_score': nova_score,
            'loan_approved': loan_decision['approved'],
            'loan_amount': loan_decision.get('max_amount', 0),
            'interest_rate': loan_decision.get('interest_rate', 0),
            'risk_category': risk_category,
            'additional_data': partner_data
        }
        
        assessment_id = save_assessment(assessment_data)
        
        return jsonify({
            'assessment_id': assessment_id,
            'partner_type': partner_type,
            'partner_name': partner_data.get('partner_name', 'Partner'),
            'nova_score': nova_score,
            'risk_category': risk_category,
            'loan_decision': loan_decision,
            'recommendations': recommendations,
            'timestamp': datetime.utcnow().isoformat()
        })
        
    except ValueError as e:
        logger.error(f"Validation error: {str(e)}")
        return jsonify({'error': 'Validation error', 'message': str(e)}), 400
    except RuntimeError as e:
        logger.error(f"Database error: {str(e)}")
        return jsonify({'error': 'Database error', 'message': str(e)}), 500
    except Exception as e:
        logger.error(f"Assessment error: {str(e)}")
        return jsonify({'error': 'Assessment failed', 'message': str(e)}), 500

@app.route("/api/batch-assess", methods=['POST'])
def batch_assess():
    """Batch assess multiple partners from CSV"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not file.filename.endswith('.csv'):
            return jsonify({'error': 'File must be a CSV'}), 400
        
        # Read CSV file
        stream = io.StringIO(file.stream.read().decode("UTF8"), newline=None)
        df = pd.read_csv(stream)
        
        results = []
        calculator = NovaScoreCalculator()
        
        for _, row in df.iterrows():
            try:
                data = row.to_dict()
                partner_type = data.get('partner_type', 'driver')
                
                # Skip rows with missing essential data
                if pd.isna(data.get('monthly_earning')) or pd.isna(data.get('customer_rating')):
                    continue
                
                # Calculate assessment
                nova_score = calculator.calculate_score(partner_type, data)
                risk_category = calculator.get_risk_category(nova_score)
                loan_decision = calculator.make_loan_decision(
                    nova_score,
                    data.get('monthly_earning', 0),
                    data.get('working_tenure_ingrab', 0)
                )
                
                # Save to MongoDB
                assessment_data = {
                    'partner_type': partner_type,
                    'partner_name': data.get('partner_name', f'Partner_{len(results)+1}'),
                    'monthly_earning': data.get('monthly_earning', 0),
                    'yearly_earning': data.get('yearly_earning', 0),
                    'customer_rating': data.get('customer_rating', 0),
                    'active_days': data.get('active_days', 0),
                    'working_tenure_ingrab': data.get('working_tenure_ingrab', 0),
                    'nova_score': nova_score,
                    'loan_approved': loan_decision['approved'],
                    'loan_amount': loan_decision.get('max_amount', 0),
                    'interest_rate': loan_decision.get('interest_rate', 0),
                    'risk_category': risk_category,
                    'additional_data': data
                }
                
                assessment_id = save_assessment(assessment_data)
                
                results.append({
                    'assessment_id': assessment_id,
                    'partner_name': data.get('partner_name', f'Partner_{len(results)+1}'),
                    'nova_score': nova_score,
                    'risk_category': risk_category,
                    'loan_approved': loan_decision['approved'],
                    'loan_amount': loan_decision.get('max_amount', 0)
                })
                
            except Exception as e:
                logger.error(f"Row processing error: {str(e)}")
                continue
        
        return jsonify({
            'message': f'Processed {len(results)} assessments successfully',
            'results': results,
            'total_processed': len(results),
            'total_rows': len(df)
        })
        
    except Exception as e:
        logger.error(f"Batch assessment error: {str(e)}")
        return jsonify({'error': 'Batch assessment failed', 'message': str(e)}), 500

@app.route("/api/assessment-history", methods=['GET'])
def get_history():
    """Get assessment history"""
    try:
        limit = request.args.get('limit', 100, type=int)
        partner_type = request.args.get('partner_type')
        
        history = get_assessment_history(limit, partner_type)
        
        return jsonify({
            'assessments': history,
            'total': len(history),
            'filter': {'partner_type': partner_type} if partner_type else {}
        })
        
    except RuntimeError as e:
        logger.error(f"Database error: {str(e)}")
        return jsonify({'error': 'Database error', 'message': str(e)}), 500
    except Exception as e:
        logger.error(f"History retrieval error: {str(e)}")
        return jsonify({'error': 'Failed to retrieve history', 'message': str(e)}), 500

@app.route("/api/assessment/<assessment_id>", methods=['GET'])
def get_single_assessment(assessment_id):
    """Get specific assessment by ID"""
    try:
        assessment = get_assessment_by_id(assessment_id)
        
        if not assessment:
            return jsonify({'error': 'Assessment not found'}), 404
        
        return jsonify({
            'assessment': assessment
        })
        
    except Exception as e:
        logger.error(f"Assessment retrieval error: {str(e)}")
        return jsonify({'error': 'Failed to retrieve assessment', 'message': str(e)}), 500

@app.route("/api/dashboard-stats", methods=['GET'])
def get_stats():
    """Get dashboard statistics"""
    try:
        stats = get_dashboard_stats()
        return jsonify(stats)
        
    except RuntimeError as e:
        logger.error(f"Database error: {str(e)}")
        return jsonify({'error': 'Database error', 'message': str(e)}), 500
    except Exception as e:
        logger.error(f"Stats retrieval error: {str(e)}")
        return jsonify({'error': 'Failed to retrieve stats', 'message': str(e)}), 500

@app.route("/api/health", methods=['GET'])
def health_check():
    """Health check endpoint"""
    health_status = {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "version": "2.0.0",
        "database": {
            "type": "MongoDB",
            "connected": mongo_manager is not None and mongo_manager.db is not None
        },
        "ml_model": {
            "loaded": ml_predictor.model is not None,
            "type": "CatBoost" if ml_predictor.model else "Rule-based"
        }
    }
    
    # Test database connection
    if mongo_manager and mongo_manager.db:
        try:
            mongo_manager.db.command('ping')
            health_status["database"]["ping"] = "success"
        except Exception as e:
            health_status["database"]["ping"] = f"failed: {str(e)}"
            health_status["status"] = "degraded"
    
    status_code = 200 if health_status["status"] == "healthy" else 503
    return jsonify(health_status), status_code

@app.route("/api/export-data", methods=['GET'])
def export_data():
    """Export assessment data as CSV"""
    try:
        # Get query parameters
        partner_type = request.args.get('partner_type')
        limit = request.args.get('limit', 1000, type=int)
        
        # Get data from MongoDB
        if mongo_manager is None or mongo_manager.db is None:
            return jsonify({'error': 'Database not available'}), 500
        
        query = {}
        if partner_type:
            query['partner_type'] = partner_type
        
        cursor = mongo_manager.db.assessments.find(query).sort('created_at', DESCENDING).limit(limit)
        
        # Convert to list and prepare for CSV
        data = []
        for doc in cursor:
            row = {
                'id': doc.get('_id'),
                'partner_type': doc.get('partner_type'),
                'partner_name': doc.get('partner_name'),
                'nova_score': doc.get('nova_score'),
                'risk_category': doc.get('risk_category'),
                'monthly_earning': doc.get('monthly_earning'),
                'yearly_earning': doc.get('yearly_earning'),
                'customer_rating': doc.get('customer_rating'),
                'active_days': doc.get('active_days'),
                'working_tenure_ingrab': doc.get('working_tenure_ingrab'),
                'loan_approved': doc.get('loan_approved'),
                'loan_amount': doc.get('loan_amount'),
                'interest_rate': doc.get('interest_rate'),
                'created_at': doc.get('created_at').isoformat() if doc.get('created_at') else ''
            }
            data.append(row)
        
        if not data:
            return jsonify({'error': 'No data found'}), 404
        
        # Convert to DataFrame and CSV
        df = pd.DataFrame(data)
        csv_buffer = io.StringIO()
        df.to_csv(csv_buffer, index=False)
        csv_buffer.seek(0)
        
        # Create response
        output = io.BytesIO()
        output.write(csv_buffer.getvalue().encode())
        output.seek(0)
        
        filename = f"novascore_export_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv"
        
        return send_file(
            output,
            mimetype='text/csv',
            as_attachment=True,
            download_name=filename
        )
        
    except Exception as e:
        logger.error(f"Export error: {str(e)}")
        return jsonify({'error': 'Export failed', 'message': str(e)}), 500

# ========================================================================================
# APPLICATION STARTUP AND CLEANUP
# ========================================================================================

@app.teardown_appcontext
def close_db(error):
    """Close database connections on app teardown"""
    pass

def cleanup_on_exit():
    """Cleanup function to run on application exit"""
    if mongo_manager:
        mongo_manager.close_connection()

import atexit
atexit.register(cleanup_on_exit)

if __name__ == "__main__":
    logger.info("Starting NovaScore Financial Assessment Platform v2.0 (Flask + MongoDB)")
    
    # Check MongoDB connection
    if not mongo_manager:
        logger.warning("MongoDB connection failed - application may have limited functionality")
    else:
        logger.info("MongoDB connected successfully")
        
    # Check ML model status
    if ml_predictor.model:
        logger.info("ML model loaded successfully")
    else:
        logger.warning("ML model not loaded - using rule-based fallback")
    
    app.run(host="0.0.0.0", port=8000, debug=True)